# -*- coding: utf-8 -*-

from django.conf.urls import patterns
from views import welcome, login

urlpatterns = patterns('',
  ('^$', login),
  ('^login$', login),
  ('^welcome$', welcome)
)




