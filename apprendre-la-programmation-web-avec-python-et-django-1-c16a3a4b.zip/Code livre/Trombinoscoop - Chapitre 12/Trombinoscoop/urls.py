from django.conf.urls import patterns, include
from views import welcome, login, register, register2, add_friend, show_profile, modify_profile
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
  ('^$', welcome), # au lieu de login
  ('^login$', login),
  ('^welcome$', welcome),
  ('^register$', register),
  ('^register2$', register2),
  ('^addFriend$', add_friend),
  ('^showProfile$', show_profile),
  ('^modifyProfile$', modify_profile),
  ('^admin/', include(admin.site.urls))
)





