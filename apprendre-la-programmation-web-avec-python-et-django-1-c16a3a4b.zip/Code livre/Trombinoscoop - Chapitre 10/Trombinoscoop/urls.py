from django.conf.urls import patterns, include
from views import welcome, login, register, register2
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
  ('^$', login),
  ('^login$', login),
  ('^welcome$', welcome),
  ('^register$', register),
  ('^register2$', register2),
  ('^admin/', include(admin.site.urls))
)




