from django.conf.urls import patterns
from views import welcome, login, login2

urlpatterns = patterns('',
  ('^$', login),
  ('^login$', login),
  ('^login2$', login2),
  ('^welcome$', welcome)
)




